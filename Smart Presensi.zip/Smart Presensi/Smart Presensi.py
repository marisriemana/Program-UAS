# -*- coding: utf-8 -*-
"""
Created on Sat Dec 10 21:06:48 2022

@author: Maris
"""

import cv2, os, numpy as np
import tkinter as tk
from tkinter import *
from PIL import ImageTk, Image
from datetime import datetime
import time


def notif():
    intructions.config(text="Rekam Data Telah Selesai!")
    
def rekamDataWajah():
    wajahDir = 'datawajah'
    cam = cv2.VideoCapture(0)
    cam.set(3, 640)
    cam.set(4, 480)
    faceDetector = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
    eyeDetector = cv2.CascadeClassifier('haarcascade_eye.xml')
    
    faceID = entry2.get()
    nama = entry1.get()
    nis = entry2.get()
    kelas = entry3.get()
    ambilData = 1
    while True:
        retV, frame = cam.read()
        abuabu = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = faceDetector.detectMultiScale(abuabu, 1.3, 5)
        for (x, y, w, h) in faces:
            frame = cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 255), 2)
            namaFile = str(nis) +'_'+str(nama) + '_' + str(kelas) +'_'+ str(ambilData) +'.jpg'
            cv2.imwrite(wajahDir + '/' + namaFile, frame)  
            ambilData += 1
            roiabuabu = abuabu[y:y + h, x:x + w]
            roiwarna = frame[y:y + h, x:x + w]
            eyes = eyeDetector.detectMultiScale(roiabuabu)
            for (xe, ye, we, he) in eyes:
                cv2.rectangle(roiwarna, (xe, ye), (xe + we, ye + he), (0, 255, 255), 1)
        cv2.imshow('webcamku', frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):  # jika menekan tombol q akan berhenti
            break
        elif ambilData > 10:
            break
    notif()
    cam.release()
    cv2.destroyAllWindows()  # untuk menghapus data yang sudah dibaca

# GUI
root = tk.Tk()
root.title('Smart Presensi')
root.resizable(width=False, height=False)

# Mengatur canvas (window tkinter)
canvas = tk.Canvas(root, width=700, height=400)
canvas.grid(columnspan=3, rowspan=8)
canvas.configure(bg="black")


# Judul
judul = tk.Label(root, text="Face Attendance - Smart Presensi", font=("Roboto",34),bg="#242526", fg="white")
canvas.create_window(350, 80, window=judul)

# Input data nama
entry1 = tk.Entry (root, font="Roboto")
canvas.create_window(457, 170, height=25, width=411, window=entry1)
label1 = tk.Label(root, text="Nama Siswa", font="Roboto", fg="white", bg="black")
canvas.create_window(90,170, window=label1)

# Input data nis
entry2 = tk.Entry (root, font="Roboto")
canvas.create_window(457, 210, height=25, width=411, window=entry2)
label2 = tk.Label(root, text="NIS", font="Roboto", fg="white", bg="black")
canvas.create_window(60, 210, window=label2)

# Input data kelas
entry3 = tk.Entry (root, font="Roboto")
canvas.create_window(457, 250, height=25, width=411, window=entry3)
label3 = tk.Label(root, text="Kelas", font="Roboto", fg="white", bg="black")
canvas.create_window(66, 250, window=label3)

# tombol untuk rekam data wajah
intructions = tk.Label(root, text="Selamat Datang", font=("Roboto",15),fg="white",bg="black")
canvas.create_window(370, 300, window=intructions)
Rekam_text = tk.StringVar()
Rekam_btn = tk.Button(root, textvariable=Rekam_text, font="Roboto", bg="#20bebe", fg="white", height=1, width=15,command=rekamDataWajah)
Rekam_text.set("Ambil Gambar")
Rekam_btn.place(x=300, y=350)

#Menampilkan waktu/jam 
def times():
    current_time=time.strftime('%H:%M:%S')
    clock.config(text=current_time)
    clock.after(200,times)

clock=Label(root,font=('times',15),bg="#20bebe",fg="white")
clock.place(x=550,y=350)
times()

root.mainloop()